let recognition: SpeechRecognition | null = null;

if ('webkitSpeechRecognition' in window) {
  recognition = new webkitSpeechRecognition();
  recognition.continuous = true;
  recognition.lang = 'fr-FR';
}

type CommandHandler = (command: string) => void;

export function startVoiceRecognition(onCommand: CommandHandler) {
  if (!recognition) {
    console.error("La reconnaissance vocale n'est pas supportée");
    return;
  }

  recognition.onresult = (event) => {
    const command = event.results[event.results.length - 1][0].transcript.toLowerCase();
    onCommand(command);
  };

  recognition.start();
}

export function stopVoiceRecognition() {
  recognition?.stop();
}

export function isVoiceRecognitionSupported() {
  return recognition !== null;
}

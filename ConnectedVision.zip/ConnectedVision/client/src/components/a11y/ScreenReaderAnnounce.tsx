
import React, { useEffect, useState } from "react";

interface AnnouncerProps {
  message: string;
  assertive?: boolean;
}

/**
 * Composant permettant d'annoncer des messages aux lecteurs d'écran
 */
export const ScreenReaderAnnounce: React.FC<AnnouncerProps> = ({ 
  message, 
  assertive = false 
}) => {
  const [announceMessage, setAnnounceMessage] = useState(message);

  useEffect(() => {
    setAnnounceMessage(message);
    
    // Nettoyer après annonce
    const timeout = setTimeout(() => {
      setAnnounceMessage("");
    }, 1000);
    
    return () => clearTimeout(timeout);
  }, [message]);

  const politeness = assertive ? "assertive" : "polite";

  return (
    <div 
      aria-live={politeness}
      className="sr-only"
    >
      {announceMessage}
    </div>
  );
};

/**
 * Hook pour annoncer des messages aux lecteurs d'écran
 */
export const useAnnounce = () => {
  const [message, setMessage] = useState("");
  const [assertive, setAssertive] = useState(false);

  const announce = (text: string, isAssertive = false) => {
    setMessage(text);
    setAssertive(isAssertive);
  };

  return {
    announce,
    announceMessage: message,
    assertive,
  };
};

export default ScreenReaderAnnounce;
import React, { useEffect, useState } from 'react';

interface ScreenReaderAnnounceProps {
  message: string;
}

export const ScreenReaderAnnounce: React.FC<ScreenReaderAnnounceProps> = ({ message }) => {
  const [announcements, setAnnouncements] = useState<string[]>([]);

  useEffect(() => {
    if (message && message.trim() !== '') {
      setAnnouncements(prev => [...prev, message]);
    }
  }, [message]);

  return (
    <div className="sr-only" aria-live="polite" aria-atomic="true">
      {announcements.map((announcement, index) => (
        <div key={index}>{announcement}</div>
      ))}
    </div>
  );
};

export const useScreenReader = () => {
  const [message, setMessage] = useState('');

  const announce = (text: string) => {
    setMessage(text);
    // Réinitialiser après un court délai pour permettre plusieurs annonces consécutives
    setTimeout(() => setMessage(''), 100);
  };

  return {
    announce,
    ScreenReaderComponent: <ScreenReaderAnnounce message={message} />
  };
};


import React, { useEffect, useRef, useState } from 'react';
import type { Detection } from '@shared/schema';

interface DetectionAudioFeedbackProps {
  detections: Detection[];
  enabled: boolean;
}

const DetectionAudioFeedback: React.FC<DetectionAudioFeedbackProps> = ({ 
  detections, 
  enabled 
}) => {
  const [currentDetection, setCurrentDetection] = useState<Detection | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const synthRef = useRef<SpeechSynthesis | null>(null);
  
  useEffect(() => {
    synthRef.current = window.speechSynthesis;
    
    return () => {
      if (synthRef.current && synthRef.current.speaking) {
        synthRef.current.cancel();
      }
    };
  }, []);
  
  useEffect(() => {
    if (!enabled) return;
    
    if (detections.length > 0 && JSON.stringify(detections[0]) !== JSON.stringify(currentDetection)) {
      const detection = detections[0];
      setCurrentDetection(detection);
      
      // Jouer un son en fonction du type de détection
      if (audioRef.current) {
        const audio = audioRef.current;
        
        // Configurer le son en fonction de la distance
        const volume = Math.min(1, 1 - (detection.distance / 10)); // Plus proche = plus fort
        audio.volume = volume;
        
        audio.play().catch(e => console.error("Erreur lors de la lecture audio:", e));
      }
      
      // Annoncer la détection par synthèse vocale
      if (synthRef.current) {
        // Arrêter toute annonce en cours
        if (synthRef.current.speaking) {
          synthRef.current.cancel();
        }
        
        const message = `${detection.label} à ${Math.round(detection.distance)} mètres`;
        const utterance = new SpeechSynthesisUtterance(message);
        utterance.lang = 'fr-FR';
        utterance.rate = 1.1; // Légèrement plus rapide
        utterance.pitch = 1.0;
        
        synthRef.current.speak(utterance);
      }
    }
  }, [detections, currentDetection, enabled]);
  
  // Sélectionner le son approprié selon le type de détection
  const getAudioSource = () => {
    if (!currentDetection) return '';
    
    switch (currentDetection.type) {
      case 'PERSON':
        return '/sounds/person.mp3';
      case 'CAR':
        return '/sounds/car.mp3';
      case 'TRAFFIC_LIGHT':
        return '/sounds/traffic_light.mp3';
      case 'CROSSWALK':
        return '/sounds/crosswalk.mp3';
      default:
        return '/sounds/detection.mp3';
    }
  };
  
  return (
    <div className="sr-only">
      <audio ref={audioRef} src={getAudioSource()} />
      <span>Retour audio actif: {enabled ? 'Oui' : 'Non'}</span>
    </div>
  );
};

export default DetectionAudioFeedback;
import React, { useEffect, useRef } from 'react';
import { Detection } from '@/shared/schema';

interface DetectionAudioFeedbackProps {
  detections: Detection[];
  enabled: boolean;
}

const DetectionAudioFeedback: React.FC<DetectionAudioFeedbackProps> = ({ 
  detections, 
  enabled 
}) => {
  const prevDetectionsRef = useRef<Detection[]>([]);
  const synth = useRef<SpeechSynthesis | null>(null);
  
  useEffect(() => {
    // Initialiser la synthèse vocale
    if (typeof window !== 'undefined') {
      synth.current = window.speechSynthesis;
    }
    
    return () => {
      // Arrêter toute synthèse en cours lors du démontage
      if (synth.current) {
        synth.current.cancel();
      }
    };
  }, []);
  
  useEffect(() => {
    if (!enabled || !synth.current) return;
    
    // Trouver les nouvelles détections importantes
    const newDetections = detections.filter(
      detection => !prevDetectionsRef.current.some(prev => prev.id === detection.id)
    );
    
    if (newDetections.length > 0) {
      // Prendre la première détection importante pour l'annoncer
      const importantDetection = newDetections[0];
      
      // Créer un message descriptif
      let message = `Détecté: ${getTypeNameInFrench(importantDetection.type)}`;
      
      if (importantDetection.distance) {
        message += ` à ${importantDetection.distance} mètres`;
      }
      
      if (importantDetection.direction) {
        message += `, ${getDirectionInFrench(importantDetection.direction)}`;
      }
      
      // Annoncer avec la synthèse vocale
      const utterance = new SpeechSynthesisUtterance(message);
      utterance.lang = 'fr-FR';
      utterance.rate = 1.1;  // Un peu plus rapide que la normale
      
      synth.current.cancel(); // Arrêter les précédentes annonces
      synth.current.speak(utterance);
    }
    
    // Mettre à jour les détections précédentes
    prevDetectionsRef.current = [...detections];
  }, [detections, enabled]);
  
  // Fonctions utilitaires pour la traduction
  const getTypeNameInFrench = (type: string): string => {
    const typeMap: Record<string, string> = {
      'PERSON': 'personne',
      'CAR': 'voiture',
      'CROSSWALK': 'passage piéton',
      'TRAFFIC_LIGHT': 'feu de circulation',
      'STAIRS': 'escalier',
      'TEXT': 'texte'
    };
    
    return typeMap[type] || type;
  };
  
  const getDirectionInFrench = (direction: string): string => {
    const directionMap: Record<string, string> = {
      'LEFT': 'à gauche',
      'RIGHT': 'à droite',
      'FRONT': 'devant',
      'FRONT_LEFT': 'devant à gauche',
      'FRONT_RIGHT': 'devant à droite'
    };
    
    return directionMap[direction] || direction;
  };
  
  // Ce composant ne rend rien visuellement
  return null;
};

export default DetectionAudioFeedback;


import React, { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { VolumeIcon, PauseIcon, PlayIcon, StopIcon, SkipForwardIcon } from 'lucide-react';

interface VoiceReaderProps {
  selector?: string; // Sélecteur CSS pour trouver le contenu à lire
  text?: string;     // Texte direct à lire
}

const VoiceReader: React.FC<VoiceReaderProps> = ({ selector = 'main', text }) => {
  const [isReading, setIsReading] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [availableVoices, setAvailableVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [selectedVoice, setSelectedVoice] = useState<string | null>(null);
  const utteranceRef = useRef<SpeechSynthesisUtterance | null>(null);
  
  useEffect(() => {
    // Initialiser la synthèse vocale
    const synth = window.speechSynthesis;
    
    // Récupérer les voix disponibles
    const updateVoices = () => {
      const voices = synth.getVoices();
      setAvailableVoices(voices);
      
      // Sélectionner par défaut une voix française si disponible
      const frenchVoice = voices.find(voice => voice.lang.includes('fr'));
      if (frenchVoice) {
        setSelectedVoice(frenchVoice.name);
      } else if (voices.length > 0) {
        setSelectedVoice(voices[0].name);
      }
    };
    
    updateVoices();
    
    // Certains navigateurs chargent les voix de façon asynchrone
    if (synth.onvoiceschanged !== undefined) {
      synth.onvoiceschanged = updateVoices;
    }
    
    return () => {
      if (synth.speaking) {
        synth.cancel();
      }
    };
  }, []);
  
  const extractText = (): string => {
    if (text) return text;
    
    const element = document.querySelector(selector);
    if (!element) return "Aucun contenu trouvé à lire.";
    
    // Ignorer les éléments cachés ou pour lecteurs d'écran
    const visibleText = Array.from(element.querySelectorAll('h1, h2, h3, p, li, span, button, a'))
      .filter(el => {
        const style = window.getComputedStyle(el);
        return style.display !== 'none' && 
               style.visibility !== 'hidden' && 
               !el.classList.contains('sr-only');
      })
      .map(el => el.textContent)
      .filter(Boolean)
      .join('. ');
      
    return visibleText || "Aucun contenu trouvé à lire.";
  };
  
  const startReading = () => {
    const synth = window.speechSynthesis;
    
    if (synth.speaking) {
      synth.cancel();
    }
    
    const contentToRead = extractText();
    const utterance = new SpeechSynthesisUtterance(contentToRead);
    
    // Configurer la voix
    if (selectedVoice) {
      const voice = availableVoices.find(v => v.name === selectedVoice);
      if (voice) utterance.voice = voice;
    }
    
    utterance.rate = 0.9; // Légèrement plus lent que la normale
    utterance.pitch = 1.0;
    
    utterance.onend = () => {
      setIsReading(false);
      setIsPaused(false);
    };
    
    utterance.onerror = () => {
      setIsReading(false);
      setIsPaused(false);
    };
    
    utteranceRef.current = utterance;
    synth.speak(utterance);
    setIsReading(true);
    setIsPaused(false);
  };
  
  const pauseReading = () => {
    const synth = window.speechSynthesis;
    
    if (synth.speaking && !isPaused) {
      synth.pause();
      setIsPaused(true);
    } else if (isPaused) {
      synth.resume();
      setIsPaused(false);
    }
  };
  
  const stopReading = () => {
    const synth = window.speechSynthesis;
    synth.cancel();
    setIsReading(false);
    setIsPaused(false);
  };
  
  const skipAhead = () => {
    const synth = window.speechSynthesis;
    
    // Arrêter la lecture actuelle
    if (synth.speaking) {
      synth.cancel();
    }
    
    // Extraire le texte complet
    const fullText = extractText();
    const sentences = fullText.split(/[.!?]+/).filter(Boolean);
    
    // Estimer où nous étions dans le texte et avancer de quelques phrases
    const currentIndex = Math.floor(sentences.length * 0.2); // Skip environ 20% du contenu
    const remainingText = sentences.slice(currentIndex).join('. ');
    
    if (remainingText) {
      const utterance = new SpeechSynthesisUtterance(remainingText);
      
      // Configurer la voix
      if (selectedVoice) {
        const voice = availableVoices.find(v => v.name === selectedVoice);
        if (voice) utterance.voice = voice;
      }
      
      utterance.rate = 0.9;
      utterance.pitch = 1.0;
      
      utterance.onend = () => {
        setIsReading(false);
        setIsPaused(false);
      };
      
      utteranceRef.current = utterance;
      synth.speak(utterance);
      setIsReading(true);
      setIsPaused(false);
    }
  };
  
  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button 
          variant="outline" 
          size="sm"
          className="flex items-center gap-2"
          aria-label="Lecture vocale du contenu"
        >
          <VolumeIcon className="h-4 w-4" />
          <span>Lire</span>
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-72">
        <div className="space-y-2">
          <h3 className="font-medium">Lecture vocale</h3>
          
          <div className="flex space-x-2">
            {!isReading ? (
              <Button 
                onClick={startReading} 
                size="sm"
                className="flex-1"
                aria-label="Commencer la lecture"
              >
                <PlayIcon className="h-4 w-4 mr-2" />
                Lire
              </Button>
            ) : (
              <Button 
                onClick={pauseReading} 
                size="sm"
                className="flex-1"
                aria-label={isPaused ? "Reprendre la lecture" : "Pause"}
              >
                {isPaused ? (
                  <PlayIcon className="h-4 w-4 mr-2" />
                ) : (
                  <PauseIcon className="h-4 w-4 mr-2" />
                )}
                {isPaused ? "Reprendre" : "Pause"}
              </Button>
            )}
            
            {isReading && (
              <>
                <Button 
                  onClick={stopReading}
                  size="sm"
                  variant="secondary"
                  aria-label="Arrêter la lecture"
                >
                  <StopIcon className="h-4 w-4" />
                </Button>
                
                <Button 
                  onClick={skipAhead}
                  size="sm"
                  variant="secondary"
                  aria-label="Avancer rapidement"
                >
                  <SkipForwardIcon className="h-4 w-4" />
                </Button>
              </>
            )}
          </div>
          
          {availableVoices.length > 0 && (
            <div className="pt-2">
              <label className="text-sm font-medium block mb-1">
                Voix:
              </label>
              <select
                className="w-full p-1 border rounded"
                value={selectedVoice || ''}
                onChange={(e) => setSelectedVoice(e.target.value)}
                aria-label="Sélectionner une voix"
              >
                {availableVoices.map((voice) => (
                  <option key={voice.name} value={voice.name}>
                    {voice.name} ({voice.lang})
                  </option>
                ))}
              </select>
            </div>
          )}
        </div>
      </PopoverContent>
    </Popover>
  );
};

export default VoiceReader;

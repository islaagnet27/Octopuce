import React, { forwardRef, useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Detection } from '@/shared/schema';
import { Slider } from '@/components/ui/slider';
import { Button, Label } from '@/components/ui/button';


interface AccessibleDetectionProps {
  detection: Detection;
  important?: boolean;
}

const AccessibleDetection = forwardRef<HTMLDivElement, AccessibleDetectionProps>(
  ({ detection, important = false }, ref) => {
    // Convertir le type en français pour l'affichage
    const getTypeDisplayName = (type: string): string => {
      const typeMap: Record<string, string> = {
        'PERSON': 'Personne',
        'CAR': 'Véhicule',
        'CROSSWALK': 'Passage piéton',
        'TRAFFIC_LIGHT': 'Feu de circulation',
        'STAIRS': 'Escalier',
        'TEXT': 'Texte'
      };

      return typeMap[type] || type;
    };

    // Convertir la direction en français
    const getDirectionDisplayName = (direction: string): string => {
      const directionMap: Record<string, string> = {
        'LEFT': 'À gauche',
        'RIGHT': 'À droite',
        'FRONT': 'En face',
        'FRONT_LEFT': 'Devant à gauche',
        'FRONT_RIGHT': 'Devant à droite'
      };

      return directionMap[direction] || direction;
    };

    const typeDisplayName = getTypeDisplayName(detection.type);
    const directionDisplayName = detection.direction ? getDirectionDisplayName(detection.direction) : '';

    // Construire un texte descriptif complet pour les lecteurs d'écran
    const getAccessibleDescription = (): string => {
      let description = `${typeDisplayName}`;

      if (detection.distance) {
        description += ` à ${detection.distance} mètres`;
      }

      if (detection.direction) {
        description += `, ${directionDisplayName.toLowerCase()}`;
      }

      if (detection.confidence) {
        const confidencePercent = Math.round(detection.confidence * 100);
        description += `, confiance de ${confidencePercent}%`;
      }

      if (detection.text) {
        description += `. Texte détecté: ${detection.text}`;
      }

      return description;
    };

    return (
      <Card 
        ref={ref}
        className={`mb-3 ${important ? 'border-primary border-2' : ''}`}
        aria-live={important ? 'polite' : 'off'}
      >
        <CardContent className="p-4">
          <div className="flex items-start justify-between">
            <div>
              <h3 className="text-xl font-bold mb-1">
                {typeDisplayName}
                {important && <span className="sr-only"> (Détection principale)</span>}
              </h3>

              <div className="space-y-1">
                {detection.distance && (
                  <p className="text-lg">Distance: <strong>{detection.distance} m</strong></p>
                )}

                {detection.direction && (
                  <p className="text-lg">Direction: <strong>{directionDisplayName}</strong></p>
                )}

                {detection.confidence && (
                  <p className="text-lg">
                    Confiance: <strong>{Math.round(detection.confidence * 100)}%</strong>
                  </p>
                )}

                {detection.text && (
                  <p className="text-lg mt-2">
                    Texte: <strong>{detection.text}</strong>
                  </p>
                )}
              </div>
            </div>

            {/* Indicateur visuel de direction */}
            {detection.direction && (
              <div 
                className="w-12 h-12 rounded-full bg-primary flex items-center justify-center text-primary-foreground"
                aria-hidden="true"
              >
                {getDirectionArrow(detection.direction)}
              </div>
            )}
          </div>

          {/* Description accessible pour les lecteurs d'écran */}
          <div className="sr-only">{getAccessibleDescription()}</div>
        </CardContent>
      </Card>
    );
  }
);

AccessibleDetection.displayName = 'AccessibleDetection';

// Fonction pour obtenir la flèche de direction
function getDirectionArrow(direction: string): React.ReactNode {
  switch (direction) {
    case 'LEFT':
      return '←';
    case 'RIGHT':
      return '→';
    case 'FRONT':
      return '↑';
    case 'FRONT_LEFT':
      return '↖';
    case 'FRONT_RIGHT':
      return '↗';
    default:
      return '·';
  }
}

export default AccessibleDetection;
import React, { useEffect, useState } from 'react';
import { Detection } from '@shared/schema';
import { ScreenReaderAnnounce } from './ScreenReaderAnnounce';
import DetectionAudioFeedback from './DetectionAudioFeedback';
import VoiceCommandManager from './VoiceCommandManager';
import { Slider } from '@/components/ui/slider';
import { Button, Label } from '@/components/ui/button';


interface AccessibleDetectionProps {
  detections: Detection[];
  isDetecting: boolean;
  onStartDetection: () => void;
  onStopDetection: () => void;
  audioFeedbackEnabled: boolean;
  voiceCommandsEnabled: boolean;
}

const AccessibleDetection: React.FC<AccessibleDetectionProps> = ({
  detections,
  isDetecting,
  onStartDetection,
  onStopDetection,
  audioFeedbackEnabled,
  voiceCommandsEnabled
}) => {
  const [announcement, setAnnouncement] = useState<string>('');
  const [settings, setSettings] = useState({ audioVolume: 50, maxDistance: 10 });


  // Création d'un message accessible pour les détections
  useEffect(() => {
    if (detections.length === 0) {
      return;
    }

    // Créer un message pour le lecteur d'écran
    const latestDetection = detections[0];
    const message = `Détecté: ${latestDetection.label}, distance: ${latestDetection.distance.toFixed(1)} mètres, confiance: ${(latestDetection.confidence * 100).toFixed(0)}%`;

    setAnnouncement(message);
  }, [detections]);

  // Traitement des commandes vocales liées à la détection
  const handleVoiceCommand = (command: string) => {
    let processed = true;

    const announceChange = (message: string) => {
      const utterance = new SpeechSynthesisUtterance(message);
      utterance.lang = 'fr-FR';
      window.speechSynthesis.speak(utterance);
    };

    if (command.includes('démarrer') || command.includes('commencer') || command.includes('activer') || command.includes('détecter')) {
      if (!isDetecting) {
        onStartDetection();
        announceChange('Détection démarrée');
      } else {
        announceChange('La détection est déjà active');
      }
    }
    else if (command.includes('arrêter') || command.includes('arrête') || command.includes('stop') || command.includes('désactiver')) {
      if (isDetecting) {
        onStopDetection();
        announceChange('Détection arrêtée');
      } else {
        announceChange('La détection est déjà inactive');
      }
    }
    else if (command.includes('statut') || command.includes('état')) {
      announceChange(`La détection est actuellement ${isDetecting ? 'active' : 'inactive'}`);

      if (detections.length > 0) {
        const latestDetection = detections[0];
        announceChange(`Dernière détection: ${latestDetection.label}, à ${latestDetection.distance.toFixed(1)} mètres`);
      } else {
        announceChange("Aucun objet n'a été détecté récemment");
      }
    }
    else if (command.includes('volume plus')) {
      const newVolume = Math.min(100, settings.audioVolume + 10);
      setSettings({ ...settings, audioVolume: newVolume });
      announceChange(`Volume augmenté à ${newVolume}%`);
    } else if (command.includes('volume moins')) {
      const newVolume = Math.max(0, settings.audioVolume - 10);
      setSettings({ ...settings, audioVolume: newVolume });
      announceChange(`Volume diminué à ${newVolume}%`);
    } else if (command.includes('distance plus')) {
      const newDistance = Math.min(20, settings.maxDistance + 1);
      setSettings({ ...settings, maxDistance: newDistance });
      announceChange(`Distance maximale augmentée à ${newDistance} mètres`);
    } else if (command.includes('distance moins')) {
      const newDistance = Math.max(1, settings.maxDistance - 1);
      setSettings({ ...settings, maxDistance: newDistance });
      announceChange(`Distance maximale diminuée à ${newDistance} mètres`);
    }
    else {
      processed = false;
    }

    return processed;
  };

  return (
    <div className="accessible-detection">
      <ScreenReaderAnnounce message={announcement} />

      {audioFeedbackEnabled && (
        <DetectionAudioFeedback
          detection={detections.length > 0 ? detections[0] : null}
          isEnabled={audioFeedbackEnabled}
        />
      )}

      <VoiceCommandManager
        isEnabled={voiceCommandsEnabled}
        onCommand={handleVoiceCommand} // Pass the handleVoiceCommand function
      />

      <div className="sr-only">
        <p>État de la détection: {isDetecting ? 'Active' : 'Inactive'}</p>
        {detections.length > 0 && (
          <ul>
            {detections.map((detection, index) => (
              <li key={index}>
                Objet: {detection.label},
                Distance: {detection.distance.toFixed(1)} mètres,
                Confiance: {(detection.confidence * 100).toFixed(0)}%
              </li>
            ))}
          </ul>
        )}
      </div>

      {/* Settings UI */}
      <div className="mt-4">
        <Label>Volume Audio:</Label>
        <Slider
          value={[settings.audioVolume]}
          min={0}
          max={100}
          step={1}
          onValueChange={(values) => {
            setSettings({ ...settings, audioVolume: values[0] });
          }}
          className="ml-3"
          aria-label="Régler le volume audio"
        />
        <span className="ml-2 text-sm">{settings.audioVolume}%</span>
      </div>

      {/* Contrôle de la distance */}
      <div className="flex items-center mt-4">
        <Label className="min-w-32">Distance maximale:</Label>
        <Button
          variant="outline"
          size="sm"
          className="mr-2"
          onClick={() => {
            const newDistance = Math.max(1, settings.maxDistance - 1);
            setSettings({ ...settings, maxDistance: newDistance });
          }}
          aria-label="Diminuer la distance maximale"
        >
          -
        </Button>
        <Slider
          value={[settings.maxDistance]}
          min={1}
          max={20}
          step={0.5}
          onValueChange={(values) => {
            setSettings({ ...settings, maxDistance: values[0] });
          }}
          className="ml-3"
          aria-label="Régler la distance maximale de détection"
        />
        <Button
          variant="outline"
          size="sm"
          className="ml-2"
          onClick={() => {
            const newDistance = Math.min(20, settings.maxDistance + 1);
            setSettings({ ...settings, maxDistance: newDistance });
          }}
          aria-label="Augmenter la distance maximale"
        >
          +
        </Button>
        <span className="ml-2 text-sm">{settings.maxDistance} m</span>
      </div>
    </div>
  );
};

export default AccessibleDetection;
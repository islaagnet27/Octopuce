
import React, { useState, useEffect, useRef } from 'react';
import { 
  AccessibilityCircle, 
  ZoomIn, 
  ZoomOut, 
  Volume2, 
  VolumeX 
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { 
  Popover, 
  PopoverContent, 
  PopoverTrigger 
} from '@/components/ui/popover';
import VoiceCommandManager, { CommandHandler } from './VoiceCommandManager';

type AccessibilitySettings = {
  highContrast: boolean;
  largeText: boolean;
  audioFeedback: boolean;
  screenReaderOptimized: boolean;
  fontZoom: number;
  voiceCommands: boolean;
};

const AccessibilityControl: React.FC = () => {
  const [settings, setSettings] = useState<AccessibilitySettings>({
    highContrast: false,
    largeText: false,
    audioFeedback: true,
    screenReaderOptimized: false,
    fontZoom: 100,
    voiceCommands: false
  });

  const popoverRef = useRef<HTMLDivElement>(null);
  const [isPopoverOpen, setIsPopoverOpen] = useState(false);

  // Charger les paramètres sauvegardés
  useEffect(() => {
    const savedSettings = localStorage.getItem('accessibilitySettings');
    if (savedSettings) {
      try {
        setSettings(JSON.parse(savedSettings));
      } catch (e) {
        console.error('Erreur lors du chargement des paramètres d\'accessibilité:', e);
      }
    }
  }, []);

  // Sauvegarder les paramètres
  useEffect(() => {
    localStorage.setItem('accessibilitySettings', JSON.stringify(settings));
    
    // Appliquer les paramètres
    const htmlElement = document.documentElement;
    
    if (settings.highContrast) {
      htmlElement.classList.add('high-contrast');
    } else {
      htmlElement.classList.remove('high-contrast');
    }
    
    if (settings.largeText) {
      htmlElement.classList.add('large-text');
      htmlElement.classList.add('large-controls');
    } else {
      htmlElement.classList.remove('large-text');
      htmlElement.classList.remove('large-controls');
    }
    
    // Ajuster la taille de la police
    htmlElement.style.fontSize = `${settings.fontZoom}%`;
    
    if (settings.screenReaderOptimized) {
      htmlElement.classList.add('screen-reader-optimized');
    } else {
      htmlElement.classList.remove('screen-reader-optimized');
    }
  }, [settings]);

  // Traitement des commandes vocales
  const handleVoiceCommand: CommandHandler = (command, params) => {
    let processed = true;
    
    // Fonction d'annonce vocale pour confirmer l'action
    const announceChange = (message: string) => {
      const utterance = new SpeechSynthesisUtterance(message);
      utterance.lang = 'fr-FR';
      window.speechSynthesis.speak(utterance);
    };
    
    if (command.includes('contraste')) {
      const newValue = !settings.highContrast;
      setSettings({...settings, highContrast: newValue});
      announceChange(`Mode contraste élevé ${newValue ? 'activé' : 'désactivé'}`);
    } 
    else if (command.includes('texte')) {
      const newValue = !settings.largeText;
      setSettings({...settings, largeText: newValue});
      announceChange(`Texte plus grand ${newValue ? 'activé' : 'désactivé'}`);
    }
    else if (command.includes('audio') || command.includes('retour sonore')) {
      const newValue = !settings.audioFeedback;
      setSettings({...settings, audioFeedback: newValue});
      announceChange(`Retour audio ${newValue ? 'activé' : 'désactivé'}`);
    }
    else if (command.includes('lecteur d\'écran') || command.includes('optimisé')) {
      const newValue = !settings.screenReaderOptimized;
      setSettings({...settings, screenReaderOptimized: newValue});
      announceChange(`Mode optimisé pour lecteur d'écran ${newValue ? 'activé' : 'désactivé'}`);
    }
    else if (command === 'volume') {
      if (params[0] === 'plus') {
        const newVolume = Math.min(100, settings.audioVolume + 10);
        setSettings({...settings, audioVolume: newVolume});
        announceChange(`Volume augmenté à ${newVolume} pour cent`);
      } else if (params[0] === 'moins') {
        const newVolume = Math.max(0, settings.audioVolume - 10);
        setSettings({...settings, audioVolume: newVolume});
        announceChange(`Volume diminué à ${newVolume} pour cent`);
      } else {
        // Définir une valeur précise
        const volumeValue = parseInt(params[0]);
        if (!isNaN(volumeValue) && volumeValue >= 0 && volumeValue <= 100) {
          setSettings({...settings, audioVolume: volumeValue});
          announceChange(`Volume défini à ${volumeValue} pour cent`);
        }
      }
    }
    else if (command === 'distance') {
      if (params[0] === 'plus') {
        const newDistance = Math.min(20, settings.maxDistance + 1);
        setSettings({...settings, maxDistance: newDistance});
        announceChange(`Distance maximale augmentée à ${newDistance} mètres`);
      } else if (params[0] === 'moins') {
        const newDistance = Math.max(1, settings.maxDistance - 1);
        setSettings({...settings, maxDistance: newDistance});
        announceChange(`Distance maximale diminuée à ${newDistance} mètres`);
      } else {
        // Définir une valeur précise
        const distanceValue = parseFloat(params[0]);
        if (!isNaN(distanceValue) && distanceValue > 0 && distanceValue <= 20) {
          setSettings({...settings, maxDistance: distanceValue});
          announceChange(`Distance maximale définie à ${distanceValue} mètres`);
        }
      }
    }
    else if (command.includes('zoom') || command.includes('agrandir')) {
      // Extraction du niveau de zoom si présent
      let zoomLevel = settings.fontZoom;
      
      if (params && /\d+/.test(params)) {
        const match = params.match(/\d+/);
        if (match) {
          zoomLevel = parseInt(match[0], 10);
          if (zoomLevel < 100) zoomLevel = 100;
          if (zoomLevel > 200) zoomLevel = 200;
        }
      } else if (command.includes('plus')) {
        zoomLevel = Math.min(200, zoomLevel + 10);
      } else if (command.includes('moins')) {
        zoomLevel = Math.max(100, zoomLevel - 10);
      } else if (command.includes('normal') || command.includes('défaut') || command.includes('réinitialiser')) {
        zoomLevel = 100;
      }
      
      setSettings({...settings, fontZoom: zoomLevel});
      announceChange(`Zoom défini à ${zoomLevel} pour cent`);
    }
    else if (command.includes('paramètres') && command.includes('accessibilité')) {
      setIsPopoverOpen(true);
      announceChange('Panneau des paramètres d\'accessibilité ouvert');
    }
    else if (command.includes('fermer') && command.includes('paramètres')) {
      setIsPopoverOpen(false);
      announceChange('Panneau des paramètres d\'accessibilité fermé');
    }
    else {
      processed = false;
    }
    
    return processed;
  };

  return (
    <div className="accessibility-controls flex items-center gap-2">
      <Popover open={isPopoverOpen} onOpenChange={setIsPopoverOpen}>
        <PopoverTrigger asChild>
          <Button 
            variant="outline" 
            size="icon" 
            className="relative"
            aria-label="Paramètres d'accessibilité"
          >
            <AccessibilityCircle className="h-5 w-5" />
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-80 p-4" align="end" ref={popoverRef}>
          <h2 className="text-lg font-bold mb-4" tabIndex={0}>Options d'accessibilité</h2>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <Label htmlFor="high-contrast" className="flex-1">
                Contraste élevé
              </Label>
              <Switch
                id="high-contrast"
                checked={settings.highContrast}
                onCheckedChange={(checked) => setSettings({...settings, highContrast: checked})}
                aria-label="Activer le mode contraste élevé"
              />
            </div>
            
            <div className="flex items-center justify-between">
              <Label htmlFor="large-text" className="flex-1">
                Texte plus grand
              </Label>
              <Switch
                id="large-text"
                checked={settings.largeText}
                onCheckedChange={(checked) => setSettings({...settings, largeText: checked})}
                aria-label="Activer le mode texte plus grand"
              />
            </div>
            
            <div className="flex items-center justify-between">
              <Label htmlFor="audio-feedback" className="flex-1">
                Retour audio
              </Label>
              <Switch
                id="audio-feedback"
                checked={settings.audioFeedback}
                onCheckedChange={(checked) => setSettings({...settings, audioFeedback: checked})}
                aria-label="Activer le retour audio pour les détections"
              />
            </div>
            
            <div className="flex items-center justify-between">
              <Label htmlFor="screen-reader" className="flex-1">
                Optimisé pour lecteur d'écran
              </Label>
              <Switch
                id="screen-reader"
                checked={settings.screenReaderOptimized}
                onCheckedChange={(checked) => setSettings({...settings, screenReaderOptimized: checked})}
                aria-label="Activer le mode optimisé pour lecteur d'écran"
              />
            </div>
            
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label htmlFor="font-zoom" className="flex-1">
                  Taille du texte ({settings.fontZoom}%)
                </Label>
              </div>
              <div className="flex items-center gap-2">
                <Button 
                  variant="outline" 
                  size="icon"
                  onClick={() => setSettings({...settings, fontZoom: Math.max(100, settings.fontZoom - 10)})}
                  disabled={settings.fontZoom <= 100}
                  aria-label="Réduire la taille du texte"
                >
                  <ZoomOut className="h-4 w-4" />
                </Button>
                <Slider
                  id="font-zoom"
                  min={100}
                  max={200}
                  step={10}
                  value={[settings.fontZoom]}
                  onValueChange={(value) => setSettings({...settings, fontZoom: value[0]})}
                  aria-label="Ajuster la taille du texte"
                  className="flex-1"
                />
                <Button 
                  variant="outline" 
                  size="icon"
                  onClick={() => setSettings({...settings, fontZoom: Math.min(200, settings.fontZoom + 10)})}
                  disabled={settings.fontZoom >= 200}
                  aria-label="Augmenter la taille du texte"
                >
                  <ZoomIn className="h-4 w-4" />
                </Button>
              </div>
            </div>
            
            <div className="flex items-center justify-between">
              <Label htmlFor="voice-commands" className="flex-1">
                Commandes vocales
              </Label>
              <Switch
                id="voice-commands"
                checked={settings.voiceCommands}
                onCheckedChange={(checked) => setSettings({...settings, voiceCommands: checked})}
                aria-label="Activer les commandes vocales"
              />
            </div>
            
            <div className="mt-4 border-t pt-4">
              <p className="text-sm text-muted-foreground">
                Exemples de commandes vocales : 
                <br/>"activer contraste élevé", "désactiver audio"
                <br/>"zoom plus", "zoom moins", "zoom 150"
                <br/>"distance plus", "distance moins", "distance 5"
                <br/>"volume plus", "volume moins", "volume 80"
              </p>
            </div>
          </div>
        </PopoverContent>
      </Popover>
      
      <VoiceCommandManager 
        isEnabled={settings.voiceCommands}
        onToggle={(enabled) => setSettings({...settings, voiceCommands: enabled})}
      />
    </div>
  );
};

export default AccessibilityControl;

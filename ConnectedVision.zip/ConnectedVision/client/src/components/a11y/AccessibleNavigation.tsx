
import React from 'react';
import { useLocation, Link } from 'react-router-dom';

interface NavigationItem {
  label: string;
  path: string;
  icon?: React.ReactNode;
}

interface AccessibleNavigationProps {
  items: NavigationItem[];
}

const AccessibleNavigation: React.FC<AccessibleNavigationProps> = ({ items }) => {
  const location = useLocation();
  
  return (
    <nav aria-label="Navigation principale">
      <a href="#main-content" className="skip-link">
        Aller au contenu principal
      </a>
      <ul className="flex flex-col space-y-2" role="menubar">
        {items.map((item, index) => {
          const isActive = location.pathname === item.path;
          return (
            <li key={item.path} role="none">
              <Link
                to={item.path}
                className={`
                  flex items-center p-3 rounded-md text-lg
                  focus:ring-4 focus:outline-none
                  ${isActive ? 'bg-primary text-primary-foreground' : 'hover:bg-muted'}
                `}
                role="menuitem"
                aria-current={isActive ? 'page' : undefined}
              >
                {item.icon && <span className="mr-3">{item.icon}</span>}
                {item.label}
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
};

export default AccessibleNavigation;

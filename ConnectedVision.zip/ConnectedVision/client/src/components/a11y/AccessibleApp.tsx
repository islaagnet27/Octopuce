
import React, { useEffect } from 'react';
import AccessibilityControl from './AccessibilityControl';
import { ScreenReaderAnnounce } from './ScreenReaderAnnounce';

interface AccessibleAppProps {
  children: React.ReactNode;
  title?: string;
}

const AccessibleApp: React.FC<AccessibleAppProps> = ({ 
  children, 
  title = "Application accessible" 
}) => {
  useEffect(() => {
    // Mettre à jour le titre du document
    document.title = title;
    
    // Activer la navigation au clavier
    const handleFirstTab = (e: KeyboardEvent) => {
      if (e.key === 'Tab') {
        document.body.classList.add('user-is-tabbing');
        window.removeEventListener('keydown', handleFirstTab);
      }
    };
    
    window.addEventListener('keydown', handleFirstTab);
    
    return () => {
      window.removeEventListener('keydown', handleFirstTab);
    };
  }, [title]);

  return (
    <>
      <div className="sr-only">
        <h1>Application de détection d'objets accessible</h1>
        <p>Cette application est optimisée pour l'accessibilité et inclut des fonctionnalités pour les personnes malvoyantes et non-voyantes.</p>
      </div>
      
      <a href="#main-content" className="skip-link">
        Aller au contenu principal
      </a>
      
      <header className="p-4 border-b bg-background">
        <div className="flex justify-between items-center">
          <h1 className="text-2xl font-bold">{title}</h1>
          <AccessibilityControl />
        </div>
      </header>
      
      <main id="main-content" tabIndex={-1} className="focus:outline-none">
        {children}
      </main>
      
      <footer className="p-4 border-t mt-8 text-center">
        <p>
          <small>Cette application dispose de fonctionnalités d'accessibilité pour les personnes malvoyantes.</small>
        </p>
      </footer>
      
      <ScreenReaderAnnounce message="" />
    </>
  );
};

export default AccessibleApp;

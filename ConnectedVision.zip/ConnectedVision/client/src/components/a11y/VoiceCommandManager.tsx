import React, { useState, useEffect, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Mic, MicOff } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

type CommandHandler = (command: string, params?: string) => boolean;

interface VoiceCommandManagerProps {
  isEnabled: boolean;
  onToggle?: (enabled: boolean) => void;
  onCommand?: (command: string, params: string[]) => void; // Added onCommand prop
}

const VoiceCommandManager: React.FC<VoiceCommandManagerProps> = ({
  isEnabled,
  onToggle,
  onCommand, // Using the added prop
}) => {
  const [isListening, setIsListening] = useState(false);
  const [recognition, setRecognition] = useState<SpeechRecognition | null>(null);
  const { toast } = useToast();

  // Liste des commandes reconnues
  const commands: Record<string, CommandHandler> = {
    // Ces commandes seront ajoutées par le parent via registerCommand
  };

  // Initialisation de la reconnaissance vocale
  useEffect(() => {
    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
      toast({
        title: "Reconnaissance vocale non disponible",
        description: "Votre navigateur ne prend pas en charge la reconnaissance vocale.",
        variant: "destructive"
      });
      return;
    }

    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    const recognitionInstance = new SpeechRecognition();

    recognitionInstance.continuous = true;
    recognitionInstance.interimResults = false;
    recognitionInstance.lang = 'fr-FR';

    recognitionInstance.onresult = (event) => {
      const transcript = event.results[event.results.length - 1][0].transcript.trim().toLowerCase();
      handleCommand(transcript);
    };

    recognitionInstance.onerror = (event) => {
      console.error('Erreur de reconnaissance vocale:', event.error);
      setIsListening(false);

      toast({
        title: "Erreur de reconnaissance vocale",
        description: `Une erreur s'est produite: ${event.error}`,
        variant: "destructive"
      });
    };

    recognitionInstance.onend = () => {
      if (isListening) {
        recognitionInstance.start();
      }
    };

    setRecognition(recognitionInstance);

    return () => {
      if (recognition) {
        recognition.stop();
      }
    };
  }, [isListening]);

  // Fonction pour traiter les commandes vocales
  const handleCommand = (transcript: string) => {
    // Annoncer ce qui a été compris
    const utterance = new SpeechSynthesisUtterance(`J'ai compris: ${transcript}`);
    utterance.lang = 'fr-FR';
    window.speechSynthesis.speak(utterance);

    console.log('Commande vocale reçue:', transcript);

    let normalizedText = transcript.toLowerCase().trim();
    console.log("Commande détectée:", normalizedText);


    // Commandes pour la distance
    if (normalizedText.includes('distance')) {
      if (normalizedText.includes('plus')) {
        onCommand && onCommand('distance', ['plus']); // Call onCommand if it exists
      } else if (normalizedText.includes('moins')) {
        onCommand && onCommand('distance', ['moins']); // Call onCommand if it exists
      } else {
        // Extraire une valeur de distance spécifique (This part is speculative)
        const distanceValue = extractNumberFromCommand(normalizedText);
        if (distanceValue && distanceValue > 0 && distanceValue <= 20) {
          onCommand && onCommand('distance', [distanceValue.toString()]); // Call onCommand if it exists
        }
      }
    }
    // Commandes pour le volume
    else if (normalizedText.includes('volume')) {
      if (normalizedText.includes('plus')) {
        onCommand && onCommand('volume', ['plus']); // Call onCommand if it exists
      } else if (normalizedText.includes('moins')) {
        onCommand && onCommand('volume', ['moins']); // Call onCommand if it exists
      } else {
        // Extraire un niveau de volume spécifique (This part is speculative)
        const volumeLevel = extractNumberFromCommand(normalizedText);
        if (volumeLevel && volumeLevel >= 0 && volumeLevel <= 100) {
          onCommand && onCommand('volume', [volumeLevel.toString()]); // Call onCommand if it exists
        }
      }
    }
    // ...rest of the commands... (This part remains unchanged from original)

    // Chercher les commandes qui correspondent
    let commandFound = false;

    // Vérifier les commandes exactes
    for (const [cmdPattern, handler] of Object.entries(commands)) {
      // Extraire les paramètres si nécessaire
      if (transcript.includes(cmdPattern)) {
        const params = transcript.replace(cmdPattern, '').trim();
        commandFound = handler(cmdPattern, params);
        if (commandFound) break;
      }
    }

    // Si aucune commande n'a été trouvée
    if (!commandFound) {
      const noCommandUtterance = new SpeechSynthesisUtterance("Commande non reconnue. Veuillez réessayer.");
      noCommandUtterance.lang = 'fr-FR';
      window.speechSynthesis.speak(noCommandUtterance);
    }
  };

  // Helper function to extract numbers from the command (This part is speculative)
  const extractNumberFromCommand = (text: string): number | null => {
    const match = text.match(/(\d+)/);
    return match ? parseInt(match[1], 10) : null;
  };

  // Démarrer/arrêter l'écoute
  const toggleListening = () => {
    if (!recognition) return;

    if (isListening) {
      recognition.stop();
      setIsListening(false);
      toast({
        title: "Reconnaissance vocale désactivée",
        description: "Les commandes vocales sont maintenant désactivées."
      });
    } else {
      recognition.start();
      setIsListening(true);
      toast({
        title: "Reconnaissance vocale activée",
        description: "Dites une commande pour modifier les paramètres."
      });

      // Annoncer que l'assistant vocal est prêt
      const utterance = new SpeechSynthesisUtterance("Assistant vocal activé. Vous pouvez maintenant donner des commandes.");
      utterance.lang = 'fr-FR';
      window.speechSynthesis.speak(utterance);
    }
  };

  // Fonction pour enregistrer une nouvelle commande
  const registerCommand = useCallback((commandPattern: string, handler: CommandHandler) => {
    commands[commandPattern] = handler;
  }, [commands]);

  if (!isEnabled) return null;

  return (
    <div className="voice-command-manager">
      <Button
        variant={isListening ? "default" : "outline"}
        size="icon"
        onClick={toggleListening}
        className={`relative ${isListening ? 'bg-primary text-primary-foreground' : ''}`}
        aria-label={isListening ? "Désactiver les commandes vocales" : "Activer les commandes vocales"}
      >
        {isListening ? (
          <Mic className="h-5 w-5 animate-pulse" />
        ) : (
          <MicOff className="h-5 w-5" />
        )}
        {isListening && (
          <span className="absolute top-0 right-0 h-3 w-3 rounded-full bg-green-500"></span>
        )}
      </Button>
    </div>
  );
};

export type { CommandHandler };
export default VoiceCommandManager;
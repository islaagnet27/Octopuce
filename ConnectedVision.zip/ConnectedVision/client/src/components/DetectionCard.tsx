
import React from 'react';
import type { Detection } from '@shared/schema';
import { Badge } from '@/components/ui/badge';

interface DetectionCardProps {
  detection: Detection;
  important?: boolean;
  ref?: React.Ref<HTMLDivElement>;
}

const DetectionCard: React.FC<DetectionCardProps> = React.forwardRef<HTMLDivElement, DetectionCardProps>(
  ({ detection, important = false }, ref) => {
    const formattedDistance = Math.round(detection.distance * 10) / 10;
    const formattedConfidence = Math.round(detection.confidence * 100);
    
    // Détermine le niveau de priorité pour l'accessibilité
    const ariaLive = important ? "assertive" : "polite";
    
    return (
      <div 
        ref={ref}
        className={`
          p-4 rounded-lg border-2 mb-4
          ${important ? 'border-primary bg-primary/10' : 'border-border'}
          focus:ring-4 focus:outline-none
        `}
        tabIndex={important ? 0 : -1}
        aria-live={ariaLive}
      >
        <div className="flex justify-between items-start mb-2">
          <h3 className="text-lg font-bold">{detection.label}</h3>
          <Badge variant={important ? "default" : "secondary"}>
            {detection.type}
          </Badge>
        </div>
        
        <div className="grid grid-cols-2 gap-2">
          <div className="flex flex-col">
            <span className="text-muted-foreground">Distance</span>
            <span className="text-lg font-medium">{formattedDistance} m</span>
          </div>
          
          <div className="flex flex-col">
            <span className="text-muted-foreground">Confiance</span>
            <span className="text-lg font-medium">{formattedConfidence}%</span>
          </div>
        </div>
        
        {/* Description pour lecteurs d'écran */}
        <div className="sr-only">
          {important ? "Détection importante:" : "Détection:"}
          {detection.label} de type {detection.type},
          Distance: {formattedDistance} mètres,
          Niveau de confiance: {formattedConfidence} pourcent.
        </div>
      </div>
    );
  }
);

DetectionCard.displayName = "DetectionCard";

export default DetectionCard;

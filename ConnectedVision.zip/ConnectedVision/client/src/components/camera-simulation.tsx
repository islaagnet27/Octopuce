import { useEffect, useRef, useState } from "react";
import { Settings, Detection } from "@shared/schema";
import { speak } from "@/lib/speech";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

interface Props {
  settings: Settings;
}

export default function CameraSimulation({ settings }: Props) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isStreaming, setIsStreaming] = useState(false);
  const queryClient = useQueryClient();

  const addDetection = useMutation({
    mutationFn: async (detection: Omit<Detection, "id">) => {
      const res = await apiRequest("POST", "/api/detections", detection);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/detections"] });
    },
  });

  useEffect(() => {
    if (!isStreaming) return;

    let stream: MediaStream | null = null;

    async function startCamera() {
      try {
        stream = await navigator.mediaDevices.getUserMedia({ 
          video: { 
            facingMode: 'environment',
            width: { ideal: 640 },
            height: { ideal: 480 }
          } 
        });

        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }
      } catch (err) {
        console.error("Erreur d'accès à la caméra:", err);
        setIsStreaming(false);
      }
    }

    startCamera();

    return () => {
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, [isStreaming]);

  useEffect(() => {
    if (!isStreaming || !videoRef.current || !canvasRef.current) return;

    const interval = setInterval(() => {
      const ctx = canvasRef.current?.getContext('2d');
      if (!ctx || !videoRef.current) return;

      // Capture frame from video
      ctx.drawImage(videoRef.current, 0, 0, 640, 480);

      // TODO: Ici nous traiterons l'image pour la détection d'objets
      // Pour l'instant on garde une détection simulée basique
      if (Math.random() > 0.7) { // 30% chance de détection
        const detection = {
          type: "SIGN" as const,
          label: "Passage piéton",
          confidence: 0.85,
          distance: 3.0,
          timestamp: Date.now(),
        };

        if (settings.audioEnabled) {
          speak(detection.label, settings.audioVolume);
        }
        addDetection.mutate(detection);
      }
    }, settings.detectionInterval);

    return () => clearInterval(interval);
  }, [isStreaming, settings, addDetection]);

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-semibold">Caméra</h2>
        <button
          className={`px-4 py-2 rounded ${
            isStreaming
              ? "bg-destructive text-destructive-foreground"
              : "bg-primary text-primary-foreground"
          }`}
          onClick={() => setIsStreaming(!isStreaming)}
        >
          {isStreaming ? "Arrêter" : "Démarrer"}
        </button>
      </div>

      <div className="relative">
        <video
          ref={videoRef}
          autoPlay
          playsInline
          muted
          className="w-full border border-border rounded-lg"
        />
        <canvas
          ref={canvasRef}
          width={640}
          height={480}
          className="absolute top-0 left-0 w-full h-full pointer-events-none"
        />
      </div>
    </div>
  );
}

import { useEffect } from 'react';
import type { Detection } from '@shared/schema';
import { useAnnounce } from '@/components/a11y/ScreenReaderAnnounce';

export function useDetectionAnnounce(detections: Detection[]) {
  const { announce } = useAnnounce();
  
  useEffect(() => {
    if (detections.length > 0) {
      const latestDetection = detections[0];
      
      // Créer un message descriptif pour le lecteur d'écran
      const message = `Détection: ${latestDetection.label} de type ${latestDetection.type}. 
                      Distance: ${Math.round(latestDetection.distance)} mètres. 
                      Confiance: ${Math.round(latestDetection.confidence * 100)}%.`;
      
      // Annoncer de manière assertive (interrompt la lecture en cours)
      announce(message, true);
    }
  }, [detections, announce]);
  
  return null;
}

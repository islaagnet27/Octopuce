
import { useEffect } from 'react';
import type { Detection } from '@shared/schema';

export function useHapticFeedback(detections: Detection[], enabled: boolean = true) {
  useEffect(() => {
    if (!enabled || !navigator.vibrate || detections.length === 0) return;
    
    const latestDetection = detections[0];
    
    // Vibrer si l'appareil le supporte
    if (navigator.vibrate) {
      // La durée de la vibration dépend de la proximité et du type
      const baseVibration = 100;
      let pattern: number[] = [];
      
      // Plus proche = vibration plus longue
      const proximityFactor = Math.max(0.2, 1 - (latestDetection.distance / 10));
      const intensity = Math.round(baseVibration * proximityFactor);
      
      // Différents patterns de vibration selon le type
      switch (latestDetection.type) {
        case 'PERSON':
          // Deux vibrations rapides
          pattern = [intensity, 100, intensity];
          break;
        case 'CAR':
          // Une longue vibration
          pattern = [intensity * 2];
          break;
        case 'TRAFFIC_LIGHT':
          // Trois vibrations courtes
          pattern = [intensity, 100, intensity, 100, intensity];
          break;
        case 'CROSSWALK':
          // Motif de passage piéton
          pattern = [intensity, 200, intensity, 200, intensity];
          break;
        case 'STAIRS':
          // Motif d'escalier
          pattern = [intensity, 100, intensity * 1.5, 100, intensity * 2];
          break;
        default:
          // Vibration simple
          pattern = [intensity];
      }
      
      navigator.vibrate(pattern);
    }
  }, [detections, enabled]);
}


import { useRef, useEffect } from 'react';
import type { Detection } from '@shared/schema';

export function useFocusManagement(detections: Detection[], threshold: number = 0.85) {
  const importantDetectionRef = useRef<HTMLDivElement | null>(null);
  
  useEffect(() => {
    // Identifier les détections importantes (haute confiance ou proche)
    const importantDetection = detections.find(d => 
      d.confidence > threshold || d.distance < 2
    );
    
    // Déplacer le focus vers l'élément important si nécessaire
    if (importantDetection && importantDetectionRef.current) {
      importantDetectionRef.current.focus();
    }
  }, [detections, threshold]);
  
  return { importantDetectionRef };
}

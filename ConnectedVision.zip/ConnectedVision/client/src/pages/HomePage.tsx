import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import AccessibleApp from '@/components/a11y/AccessibleApp';
import { Settings, Detection } from '@shared/schema';
import DetectionCard from '@/components/DetectionCard';
import { useDetectionAnnounce } from '@/hooks/use-detection-announce';
import { useFocusManagement } from '@/hooks/use-focus-management';
import DetectionAudioFeedback from '@/components/a11y/DetectionAudioFeedback';
import { useHapticFeedback } from '@/hooks/use-haptic-feedback';

const HomePage: React.FC = () => {
  const [settings, setSettings] = useState<Settings>({
    enabledTypes: ['PERSON', 'CAR', 'CROSSWALK', 'TRAFFIC_LIGHT', 'STAIRS'],
    maxDistance: 10,
    audioFeedback: true,
    hapticFeedback: true,
    highContrastMode: false,
    voiceCommands: false, // Added voiceCommands to settings
  });

  const [detections, setDetections] = useState<Detection[]>([]);
  const [isDetecting, setIsDetecting] = useState(false); // Added state for detection

  // Hooks d'accessibilité
  useDetectionAnnounce(detections);
  const { importantDetectionRef } = useFocusManagement(detections);
  useHapticFeedback(detections, settings.hapticFeedback);

  useEffect(() => {
    // Charger les paramètres
    fetch('/api/settings')
      .then(res => res.json())
      .then(data => setSettings(data))
      .catch(err => console.error('Erreur lors du chargement des paramètres:', err));

    // Charger les détections
    fetch('/api/detections')
      .then(res => res.json())
      .then(data => setDetections(data))
      .catch(err => console.error('Erreur lors du chargement des détections:', err));

    // Simuler de nouvelles détections
    const interval = setInterval(() => {
      fetch('/api/detections')
        .then(res => res.json())
        .then(data => setDetections(data))
        .catch(err => console.error('Erreur lors du chargement des détections:', err));
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const handleSettingChange = (key: keyof Settings, value: any) => {
    const newSettings = { ...settings, [key]: value };
    setSettings(newSettings);

    fetch('/api/settings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newSettings),
    }).catch(err => console.error('Erreur lors de la mise à jour des paramètres:', err));
  };

  const startDetection = () => {
    setIsDetecting(true);
  };

  const stopDetection = () => {
    setIsDetecting(false);
  };


  return (
    <AccessibleApp title="Détection d'objets accessible">
      <div className="container mx-auto p-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Section des paramètres */}
          <Card className="md:col-span-1">
            <CardHeader>
              <CardTitle>Paramètres</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <h3 className="text-lg font-medium mb-2">Types de détection</h3>
                  {['PERSON', 'CAR', 'CROSSWALK', 'TRAFFIC_LIGHT', 'STAIRS', 'TEXT'].map((type) => (
                    <div key={type} className="flex items-center space-x-2 mb-2">
                      <Switch
                        id={`type-${type}`}
                        checked={settings.enabledTypes.includes(type as any)}
                        onCheckedChange={(checked) => {
                          const types = checked
                            ? [...settings.enabledTypes, type]
                            : settings.enabledTypes.filter(t => t !== type);
                          handleSettingChange('enabledTypes', types);
                        }}
                        aria-label={`Activer la détection de ${type}`}
                      />
                      <Label htmlFor={`type-${type}`}>{type}</Label>
                    </div>
                  ))}
                </div>

                <div>
                  <h3 className="text-lg font-medium mb-2">Options d'accessibilité</h3>
                  <div className="flex items-center space-x-2 mb-2">
                    <Switch
                      id="audio-feedback"
                      checked={settings.audioFeedback}
                      onCheckedChange={(checked) => handleSettingChange('audioFeedback', checked)}
                      aria-label="Activer le retour audio"
                    />
                    <Label htmlFor="audio-feedback">Retour audio</Label>
                  </div>

                  <div className="flex items-center space-x-2 mb-2">
                    <Switch
                      id="haptic-feedback"
                      checked={settings.hapticFeedback}
                      onCheckedChange={(checked) => handleSettingChange('hapticFeedback', checked)}
                      aria-label="Activer les vibrations"
                    />
                    <Label htmlFor="haptic-feedback">Vibrations</Label>
                  </div>

                  <div className="flex items-center space-x-2">
                    <Switch
                      id="high-contrast"
                      checked={settings.highContrastMode}
                      onCheckedChange={(checked) => handleSettingChange('highContrastMode', checked)}
                      aria-label="Activer le mode contraste élevé"
                    />
                    <Label htmlFor="high-contrast">Contraste élevé</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch
                      id="voice-commands"
                      checked={settings.voiceCommands}
                      onCheckedChange={(checked) => handleSettingChange('voiceCommands', checked)}
                      aria-label="Activer les commandes vocales"
                    />
                    <Label htmlFor="voice-commands">Commandes vocales</Label>
                  </div>
                </div>

                <Button
                  className="w-full mt-4"
                  onClick={() => {
                    // Action d'assistance
                    const synth = window.speechSynthesis;
                    const utterance = new SpeechSynthesisUtterance("Mode d'assistance activé. Je vais vous guider dans l'utilisation de l'application.");
                    utterance.lang = 'fr-FR';
                    synth.speak(utterance);
                  }}
                >
                  Activer l'assistance vocale
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Section des détections */}
          <Card className="md:col-span-2">
            <CardHeader>
              <CardTitle>Détections récentes</CardTitle>
            </CardHeader>
            <CardContent>
              {detections.length === 0 ? (
                <p className="text-center text-muted-foreground p-4" tabIndex={0}>
                  Aucune détection récente
                </p>
              ) : (
                <div className="space-y-4">
                  {detections.map((detection, index) => (
                    <DetectionCard
                      key={detection.id || index}
                      detection={detection}
                      important={index === 0}
                      ref={index === 0 ? importantDetectionRef : undefined}
                    />
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Composants d'accessibilité invisibles */}
      <DetectionAudioFeedback
        detections={detections}
        enabled={settings.audioFeedback}
      />
    </AccessibleApp>
  );
};

export default HomePage;